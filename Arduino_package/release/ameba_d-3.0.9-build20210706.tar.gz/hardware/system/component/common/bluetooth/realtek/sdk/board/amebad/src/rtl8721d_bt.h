#ifndef _RTL8721D_BT_H_
#define _RTL8721D_BT_H_

const unsigned char *bt_get_patch_code_8721d(_adapter *padapter);
unsigned int bt_get_patch_code_len_8721d(_adapter *padapter);

#endif // _RTL8721D_BT_H_
