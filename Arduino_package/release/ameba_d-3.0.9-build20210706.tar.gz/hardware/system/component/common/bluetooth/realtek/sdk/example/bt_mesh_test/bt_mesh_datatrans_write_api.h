#ifndef BT_MESH_DATATRANS_WRITE_H
#define BT_MESH_DATATRANS_WRITE_H

void bt_mesh_cmd_datatrans_write_api(uint16_t mesh_addr, uint8_t * data_array, uint16_t data_len);

#endif /* BT_MESH_DATATRANS_WRITE_H */