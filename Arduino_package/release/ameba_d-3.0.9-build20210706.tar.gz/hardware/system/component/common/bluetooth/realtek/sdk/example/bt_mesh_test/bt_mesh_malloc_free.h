#ifndef BT_MESH_MALLOC_FREE_H
#define BT_MESH_MALLOC_FREE_H

void *bt_mesh_test_malloc(size_t size);
void bt_mesh_test_free(void *ptr);

#endif /* BT_MESH_MALLOC_FREE_H */