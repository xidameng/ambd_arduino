#ifndef _EXAMPLE_BT_MESH_H_
#define _EXAMPLE_BT_MESH_H_

void example_bt_mesh(void);

#endif /* _EXAMPLE_BT_MESH_DEMO_H_ */

